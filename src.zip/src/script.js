const form = document.getElementById("form");

form.addEventListener("submit", (e) => {
    e.preventDefault();

    const firstName = document.getElementById("FirstName");
    const firstNameError = document.getElementById("FirstNameError");

    const lastName = document.getElementById("LastName");
    const lastNameError = document.getElementById("LastNameError"); 

    const emailAddress = document.getElementById("EmailAddress");
    const emailAddressError = document.getElementById("EmailAddressError");

    const query = document.querySelector('input[name="query"]:checked');
    const queryError = document.getElementById("QueryTypeError"); 

    const messageArea = document.getElementById("MessageArea");
    const messageAreaError = document.getElementById("MessageAreaError"); 

    const accept= document.getElementById("Accept");
    const acceptError = document.getElementById("AcceptError");

    if(firstName.value == ""){
        firstName.classList.add('errorInput'); 
        firstNameError.textContent = "This field is required";
    }
    else {
        firstName.classList.remove("errorInput");
        firstNameError.textContent = "";
    }

    if(lastName.value == ""){
        lastName.classList.add("errorInput"); 
        lastNameError.textContent = "This field is required";
    }
    else {
        firstName.classList.remove("errorInput");
        firstNameError.textContent = "";
    }

    if(emailAddress.value.includes("@")){
        firstName.classList.add("errorInput");   
        emailAddressError.textContent = "Please enter a valid email address";
    }
    else {
        firstName.classList.remove("errorInput");
        firstNameError.textContent = "";
    }

    if(!query){
        firstName.classList.add("errorInput");   
        queryError.textContent = "Please select a query type";
    }
    else {
        firstName.classList.remove("errorInput");
        firstNameError.textContent = "";
    }

    if(messageArea.value == ""){
        firstName.classList.add("errorInput");   
        messageAreaError.textContent = "This field is required";
    }
    else {
        firstName.classList.remove("errorInput");
        firstNameError.textContent = "";
    }

    if(!accept.checked){
        firstName.classList.add("errorInput");   
        acceptError.textContent = "To submit this form, please consent to being contacted";
    }
    else {
        firstName.classList.remove("errorInput");
        firstNameError.textContent = "";
    }

    console.log('klik')
});

